package com.ankit.voice;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.app.SearchManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int SPEECH = 1, PERMS = 2;
    private TextView log;
    private Switch hindi;
    private TextToSpeech tts;
    private boolean autoListen;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);

        log = new TextView(this);
        log.setTextSize(18);
        log.setGravity(Gravity.CENTER);
        log.setText("FRIDAY\n\n\"Rahul ko call karo\"\n\"Rahul ko message bhejo ki main aa raha hoon\"\n"
                + "\"Rahul ko WhatsApp message bhejo ki hello\"\n\"YouTube par Kesariya gaana chalao\"\n"
                + "\"Instagram par Virat Kohli ko follow karo\"\n\"Instagram kholo\"\n"
                + "\"shaam 7 baje alarm lagao\"\n");

        Button mic = new Button(this);
        mic.setText("🎤  Boliye");
        mic.setTextSize(24);
        mic.setOnClickListener(v -> listen());

        hindi = new Switch(this);
        hindi.setText("Hindi mein sunna  ");

        root.addView(log);
        root.addView(mic);
        root.addView(hindi);

        Button access = new Button(this);
        access.setText("Accessibility chalu karein");
        access.setOnClickListener(v -> start(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(root);
        setContentView(scroll);
        autoListen = b == null;

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });
        requestPermissions(new String[]{Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS}, PERMS);
    }

    /** App khulte hi sunna shuru, button dabane ki zarurat nahi. */
    @Override
    public void onRequestPermissionsResult(int req, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(req, permissions, results);
        if (autoListen && results.length > 0) {
            autoListen = false;
            log.post(this::listen);
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }

    private void listen() {
        String lang = hindi.isChecked() ? "hi-IN" : "en-IN";
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        try {
            startActivityForResult(i, SPEECH);
        } catch (ActivityNotFoundException e) {
            say("Google app install ya enable kijiye");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != SPEECH || res != RESULT_OK || data == null) return;
        ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (r == null || r.isEmpty()) return;
        log.setText("Aapne kaha:\n" + r.get(0));
        run(CommandParser.parse(r.get(0)));
    }

    private void say(String msg) {
        log.append("\n\n" + msg);
        tts.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "reply");
    }

    private boolean start(Intent i) {
        try {
            startActivity(i);
            return true;
        } catch (ActivityNotFoundException | SecurityException e) {
            say("Ye kaam is phone par nahi ho paya");
            return false;
        }
    }

    private void run(CommandParser.Command c) {
        switch (c.type) {
            case CALL:
                withNumber(c.target, false, (name, number) -> {
                    boolean ok = granted(Manifest.permission.CALL_PHONE);
                    say(name + " ko call");
                    start(new Intent(ok ? Intent.ACTION_CALL : Intent.ACTION_DIAL,
                            Uri.fromParts("tel", number, null)));
                });
                break;
            case MESSAGE:
                if (c.text.isEmpty()) { say("Message bhi boliye: Rahul ko message bhejo ki ..."); break; }
                withNumber(c.target, true, (name, number) -> {
                    if (c.whatsapp) whatsapp(name, number, c.text);
                    else sms(name, number, c.text);
                });
                break;
            case PLAY: {
                FridayService f = service();
                Intent yt = new Intent(Intent.ACTION_VIEW, Uri.parse(
                        "https://www.youtube.com/results?search_query=" + Uri.encode(c.target)))
                        .setPackage(FridayService.YOUTUBE)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                if (f != null && start(yt)) f.playFirstVideo();
                break;
            }
            case FOLLOW: {
                if (c.target.isEmpty()) { say("Kise follow karna hai?"); break; }
                FridayService f = service();
                if (f == null) break;
                Intent ig = getPackageManager().getLaunchIntentForPackage(FridayService.INSTAGRAM);
                if (ig == null) { say("Instagram install nahi hai"); break; }
                ig.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                if (start(ig)) f.follow(c.target);
                break;
            }
            case TIMER:
                if (c.seconds < 1 || c.seconds > 86400) { say("Timer 24 ghante tak ka hi lag sakta hai"); break; }
                say("Timer laga raha hoon");
                start(new Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, c.seconds)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, c.text.isEmpty() ? "Reminder" : c.text)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, false));
                break;
            case ALARM:
                alarm(c);
                break;
            case SEARCH:
                search(c);
                break;
            case OPEN:
                openApp(c.target);
                break;
            default:
                say("Samajh nahi aaya, dobara boliye");
        }
    }

    private void alarm(CommandParser.Command c) {
        if (c.hour < 0) { say("Time bhi boliye, jaise shaam 7 baje"); return; }
        Calendar now = Calendar.getInstance();
        int hour = c.hour;
        // subah/shaam nahi bola to agla aane wala samay lo
        if (!c.amPmKnown && !c.tomorrow) {
            int nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
            int am = (c.hour % 12) * 60 + c.minute, pm = am + 720;
            if (am <= nowMin && pm > nowMin) hour = c.hour % 12 + 12;
            else hour = c.hour % 12;
        }
        String title = c.text.isEmpty() ? "Reminder" : c.text;
        if (c.tomorrow) {
            // Alarm sirf agle 24 ghante ke liye hota hai, isliye "kal" calendar mein jata hai
            Calendar when = (Calendar) now.clone();
            when.add(Calendar.DAY_OF_YEAR, 1);
            when.set(Calendar.HOUR_OF_DAY, hour);
            when.set(Calendar.MINUTE, c.minute);
            when.set(Calendar.SECOND, 0);
            say("Calendar mein Save dabaiye");
            start(new Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, title)
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, when.getTimeInMillis()));
        } else {
            say(String.format(Locale.US, "%d bajkar %d minute ka alarm laga raha hoon", hour, c.minute));
            start(new Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, c.minute)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, title));
        }
    }

    private void search(CommandParser.Command c) {
        if (c.youtube) {
            start(new Intent(Intent.ACTION_VIEW, Uri.parse(
                    "https://www.youtube.com/results?search_query=" + Uri.encode(c.target))));
        } else {
            start(new Intent(Intent.ACTION_VIEW, Uri.parse(
                    "https://www.google.com/search?q=" + Uri.encode(c.target))));
        }
    }

    private void openApp(String name) {
        String[][] alias = {
            {"इंस्टाग्राम", "instagram"}, {"insta", "instagram"}, {"इंस्टा", "instagram"},
            {"फेसबुक", "facebook"}, {"व्हाट्सएप", "whatsapp"}, {"व्हाट्सऐप", "whatsapp"},
            {"वॉट्सऐप", "whatsapp"}, {"यूट्यूब", "youtube"}, {"कैमरा", "camera"},
            {"क्रोम", "chrome"}, {"सेटिंग", "settings"}, {"सेटिंग्स", "settings"},
            {"गैलरी", "gallery"}, {"टेलीग्राम", "telegram"}, {"स्नैपचैट", "snapchat"},
            {"मैप", "maps"}, {"गूगल", "google"}};
        String want = name;
        for (String[] a : alias) if (want.equals(a[0])) want = a[1];
        want = want.replace(" ", "");
        if (want.isEmpty()) { say("Kaunsa app kholna hai?"); return; }

        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        ResolveInfo best = null;
        int bestScore = 0;
        for (ResolveInfo info : pm.queryIntentActivities(q, 0)) {
            String label = info.loadLabel(pm).toString().toLowerCase(Locale.ROOT).replace(" ", "");
            int score = label.equals(want) ? 3 : label.startsWith(want) ? 2 : label.contains(want) ? 1 : 0;
            if (score > bestScore) { best = info; bestScore = score; }
        }
        if (best == null) { say(name + " naam ka app nahi mila"); return; }
        say(best.loadLabel(pm) + " khol raha hoon");
        start(new Intent(q).setClassName(best.activityInfo.packageName, best.activityInfo.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }

    private interface NumberAction { void go(String name, String number); }

    private boolean granted(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private FridayService service() {
        if (FridayService.instance == null) {
            say("Pehle Settings mein Friday ki Accessibility chalu kijiye");
            start(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }
        return FridayService.instance;
    }

    private void sms(String name, String number, String text) {
        if (!granted(Manifest.permission.SEND_SMS)) {
            say("SMS ki permission dijiye, phir dobara boliye");
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, PERMS);
            return;
        }
        final String action = getPackageName() + ".SMS_SENT." + System.nanoTime();
        BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                say(getResultCode() == RESULT_OK ? name + " ko message chala gaya"
                        : "Message nahi gaya. SIM, balance aur default SMS SIM check kijiye");
                getApplicationContext().unregisterReceiver(this);
            }
        };
        IntentFilter filter = new IntentFilter(action);
        if (Build.VERSION.SDK_INT >= 33)
            getApplicationContext().registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else getApplicationContext().registerReceiver(receiver, filter);
        try {
            SmsManager manager = Build.VERSION.SDK_INT >= 31
                    ? getSystemService(SmsManager.class) : SmsManager.getDefault();
            ArrayList<String> parts = manager.divideMessage(text);
            PendingIntent sent = PendingIntent.getBroadcast(this, 0,
                    new Intent(action).setPackage(getPackageName()), PendingIntent.FLAG_IMMUTABLE);
            ArrayList<PendingIntent> sentList = new ArrayList<>(Collections.nCopies(parts.size(), (PendingIntent) null));
            sentList.set(parts.size() - 1, sent);
            manager.sendMultipartTextMessage(number, null, parts, sentList, null);
        } catch (RuntimeException e) {
            getApplicationContext().unregisterReceiver(receiver);
            say("Message nahi gaya");
        }
    }

    private void whatsapp(String name, String number, String text) {
        FridayService f = service();
        if (f == null) return;
        String n = number.replaceAll("[^0-9+]", "");
        // wa.me ko country code chahiye; bina code wale number ko India (91) maana hai
        if (n.startsWith("+")) n = n.substring(1);
        else if (n.startsWith("00")) n = n.substring(2);
        else if (n.length() == 11 && n.startsWith("0")) n = "91" + n.substring(1);
        else if (n.length() == 10) n = "91" + n;
        Uri uri = Uri.parse("https://wa.me/" + n + "?text=" + Uri.encode(text));
        for (String app : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
            if (getPackageManager().getLaunchIntentForPackage(app) == null) continue;
            if (start(new Intent(Intent.ACTION_VIEW, uri).setPackage(app))) f.sendWhatsApp(app, name, text);
            return;
        }
        say("WhatsApp install nahi hai");
    }

    /** strict = true (message): ek se zyada log milein to bhejo mat, poora naam poochho. */
    private void withNumber(String who, boolean strict, NumberAction action) {
        if (who.isEmpty()) { say("Naam ya number boliye"); return; }
        if (who.matches("\\+?\\d{3,}")) { action.go(who, who); return; }
        if (!granted(Manifest.permission.READ_CONTACTS)) {
            say("Contacts ki permission dijiye, phir dobara boliye");
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, PERMS);
            return;
        }
        Uri uri = Uri.withAppendedPath(Phone.CONTENT_FILTER_URI, Uri.encode(who));
        // Behtar match pehle: poora naam, phir pehla shabd, phir baaki. Barabari par default aur mobile number.
        LinkedHashMap<String, String> people = new LinkedHashMap<>();
        int best = 0;
        List<String[]> top = new ArrayList<>();
        try (Cursor cur = getContentResolver().query(uri,
                new String[]{Phone.DISPLAY_NAME, Phone.NUMBER, Phone.TYPE, Phone.IS_SUPER_PRIMARY},
                null, null, Phone.IS_SUPER_PRIMARY + " DESC, " + Phone.DISPLAY_NAME)) {
            while (cur != null && cur.moveToNext()) {
                String n = cur.getString(0), num = cur.getString(1);
                if (n == null || num == null) continue;
                String low = n.toLowerCase(Locale.ROOT).trim();
                int score = (low.equals(who) ? 3 : low.startsWith(who + " ") ? 2 : 1) * 4
                        + (cur.getInt(3) != 0 ? 2 : 0)
                        + (cur.getInt(2) == Phone.TYPE_MOBILE ? 1 : 0);
                int rank = score / 4;
                if (rank > best / 4) { top.clear(); people.clear(); }
                if (rank >= best / 4) {
                    people.put(low, n);
                    top.add(new String[]{n, num.replaceAll("[ ()-]", ""), String.valueOf(score)});
                }
                best = Math.max(best, score);
            }
        }
        if (top.isEmpty()) { say(who + " contacts mein nahi mila"); return; }
        if (strict && people.size() > 1) {
            say("Ek se zyada contact mile: " + String.join(", ", people.values())
                    + ". Poora naam bolkar dobara boliye");
            return;
        }
        String[] pick = top.get(0);
        for (String[] x : top) if (Integer.parseInt(x[2]) > Integer.parseInt(pick[2])) pick = x;
        action.go(pick[0], pick[1]);
    }
}
