package com.ankit.voice;

import java.util.*;
import java.util.regex.*;

/** Boli gayi baat (Hindi / Hinglish / English) ko command mein badalta hai. */
public class CommandParser {
    public enum Type { CALL, MESSAGE, TIMER, ALARM, PLAY, FOLLOW, SEARCH, OPEN, UNKNOWN }

    public static class Command {
        public Type type = Type.UNKNOWN;
        public String target = "";   // naam, number, app ya search query
        public String text = "";     // message ya reminder ka text
        public int seconds, hour = -1, minute;
        public boolean amPmKnown, tomorrow, youtube, whatsapp;
    }

    private static Set<String> words(String s) {
        return new HashSet<>(Arrays.asList(s.split(" ")));
    }

    private static final Set<String> MSG = words("message msg sms text मैसेज मेसेज संदेश एसएमएस");
    private static final Set<String> CALL = words("call phone dial कॉल काल फोन फ़ोन डायल");
    private static final Set<String> REMIND = words("reminder remind alarm timer रिमाइंडर अलार्म टाइमर");
    private static final Set<String> SEARCH = words("search सर्च खोजो ढूंढो");
    private static final Set<String> OPEN = words("open kholo khol kholiye chalao chala chalu start launch खोलो खोल खोलिए चलाओ चलाइए चला चालू ओपन");
    private static final Set<String> FOLLOW = words("follow फॉलो फ़ॉलो");
    private static final Set<String> NO = words("mat nahi nahin don't dont not मत नहीं");
    private static final Set<String> PLAY = words("play chalao bajao sunao lagao chala baja प्ले चलाओ बजाओ सुनाओ लगाओ");
    private static final Set<String> SONG = words("song songs gana gaana gane gaane music video गाना गाने सॉन्ग म्यूजिक वीडियो");
    private static final Set<String> YT = words("youtube यूट्यूब");
    private static final Set<String> WA = words("whatsapp व्हाट्सएप व्हाट्सऐप वॉट्सऐप वॉट्सएप व्हाट्सअप");
    private static final Set<String> FILLER = words(
        "karo kar kardo do dena de lagao laga lagana bhejo bhej send set please plz the a an to for at on me mujhe mera meri mere ko ka ki ke par pe app " +
        "करो कर दो देना दे लगाओ लगा भेजो भेज प्लीज मुझे मेरा मेरी मेरे को का की के पर पे ऐप एप");

    public static Command parse(String spoken) {
        Command c = new Command();
        String o = spoken.trim()
                .replaceAll("[,!?।]", " ").replaceAll("\\.(?=\\s|$)", " ")
                .replaceAll("(?i)\\ba\\.\\s?m\\b", "am").replaceAll("(?i)\\bp\\.\\s?m\\b", "pm")
                .replaceAll("\\s+", " ").trim();
        // "Friday, ..." ya "Hey Friday ..." se naam hata do
        o = o.replaceFirst("(?i)^(?:(?:hey|hi|ok|okay|हे|ओके) )?(?:friday|फ्राइडे|फ़्राइडे|फ्राईडे)(?: |$)", "");
        for (int i = 0; i < 10; i++) o = o.replace((char) ('०' + i), (char) ('0' + i));
        String s = o.toLowerCase(Locale.ROOT);
        List<String> original = Arrays.asList(o.split(" "));
        List<String> t = new ArrayList<>(Arrays.asList(s.split(" ")));

        // "remind me to send a message" reminder hai, message nahi
        int msg = first(t, MSG), rem = first(t, REMIND);
        if (rem >= 0 && (msg < 0 || rem < msg)) return reminder(c, s, t);
        if (msg >= 0) return message(c, t, original, msg);
        if (first(t, FOLLOW) >= 0) {
            if (first(t, NO) >= 0) return c;
            c.type = Type.FOLLOW;
            c.target = clean(t, FOLLOW, words("instagram insta इंस्टाग्राम इंस्टा search सर्च karke करके aur और and use usko usse उसे उसको account अकाउंट id आईडी who उस"));
            return c;
        }
        boolean yt = first(t, YT) >= 0;
        if (first(t, PLAY) >= 0 && first(t, CALL) < 0
                && (yt || first(t, SONG) >= 0 || t.contains("play") || t.contains("bajao") || t.contains("बजाओ"))) {
            if (first(t, NO) >= 0) return c;
            Set<String> drop = words("karo kar do please youtube यूट्यूब करो कर दो प्लीज");
            drop.addAll(PLAY);
            List<String> q = new ArrayList<>(t);
            q.removeAll(drop);
            // "youtube par ..." / "... on youtube" ke jodne wale shabd
            Set<String> join = words("par pe on पर पे");
            while (!q.isEmpty() && join.contains(q.get(0))) q.remove(0);
            while (!q.isEmpty() && join.contains(q.get(q.size() - 1))) q.remove(q.size() - 1);
            c.target = String.join(" ", q);
            c.type = Type.PLAY;
            if (c.target.isEmpty()) { c.type = Type.OPEN; c.target = "youtube"; }
            return c;
        }
        if (first(t, SEARCH) >= 0) {
            c.type = Type.SEARCH;
            c.youtube = s.contains("youtube") || s.contains("यूट्यूब");
            c.target = clean(t, SEARCH, words("google youtube गूगल यूट्यूब"));
            return c;
        }
        if (first(t, CALL) >= 0) {
            if (first(t, NO) >= 0) return c;   // "call mat karo"
            c.type = Type.CALL;
            c.target = clean(t, CALL, words("lagana milao मिलाओ"));
            String digits = c.target.replaceAll("[ -]", "");
            if (digits.matches("\\+?\\d{3,}")) c.target = digits;
            return c;
        }
        if (first(t, OPEN) >= 0) {
            c.type = Type.OPEN;
            c.target = clean(t, OPEN, words("mera मेरा"));
        }
        return c;
    }

    private static int first(List<String> t, Set<String> set) {
        for (int i = 0; i < t.size(); i++) if (set.contains(t.get(i))) return i;
        return -1;
    }

    private static String clean(List<String> t, Set<String> a, Set<String> b) {
        StringBuilder out = new StringBuilder();
        for (String w : t)
            if (!a.contains(w) && !b.contains(w) && !FILLER.contains(w)) out.append(w).append(' ');
        return out.toString().trim();
    }

    private static Command message(Command c, List<String> t, List<String> original, int at) {
        c.type = Type.MESSAGE;
        Set<String> sep = words("ki कि that saying bolo likho लिखो बोलो");
        int cut = -1;
        for (int i = 0; i < t.size(); i++) {
            // "ki" ko separator tabhi maano jab wo message shabd ke baad aaye
            if (i > at && sep.contains(t.get(i))) { cut = i; break; }
        }
        List<String> head = cut < 0 ? t : t.subList(0, cut);
        c.whatsapp = first(head, WA) >= 0;
        c.target = clean(head, MSG, WA);
        if (cut >= 0) c.text = String.join(" ", original.subList(cut + 1, original.size()));
        return c;
    }

    private static Command reminder(Command c, String s, List<String> t) {
        String used = null;
        Matcher d = Pattern.compile("(\\d+) ?(seconds?|sec|सेकंड|minutes?|mins?|मिनट|hours?|ghante|ghanta|घंटे|घंटा)(?: (?:baad|बाद|mein|में|later))?").matcher(s);
        Matcher a = Pattern.compile("(\\d{1,2})(?:[:.](\\d{2}))? ?(baje|बजे|am|pm|o'clock)").matcher(s);
        if (!a.find()) {
            a = Pattern.compile("(?:at|for) (\\d{1,2})(?:[:.](\\d{2}))?()").matcher(s);
            if (!a.find()) a = null;
        }
        if (d.find()) {
            c.type = Type.TIMER;
            String u = d.group(2);
            int mult = u.startsWith("s") || u.startsWith("से") ? 1 : u.startsWith("m") || u.startsWith("मि") ? 60 : 3600;
            c.seconds = Integer.parseInt(d.group(1).length() > 5 ? "99999" : d.group(1)) * mult;
            used = d.group();
        } else {
            c.type = Type.ALARM;
            if (a != null) {
                int h = Integer.parseInt(a.group(1));
                int m = a.group(2) == null ? 0 : Integer.parseInt(a.group(2));
                boolean pm = has(t, "pm shaam sham raat dopahar evening night afternoon शाम रात दोपहर");
                boolean am = has(t, "am subah morning सुबह");
                if (h <= 23 && m <= 59) {
                    if (am || pm) {
                        // raat 12 baje = 0, raat 1-4 baje = subah ke ghante
                        boolean night = has(t, "raat night रात");
                        if (h == 12) h = (am || night) ? 0 : 12;
                        else if (pm && h < 12 && !(night && h < 5)) h += 12;
                    }
                    c.hour = h;
                    c.minute = m;
                    c.amPmKnown = am || pm || h > 12 || h == 0;
                }
                used = a.group();
            }
        }
        c.tomorrow = has(t, "kal tomorrow कल");
        if (used != null) s = s.replace(used, " ");
        c.text = clean(Arrays.asList(s.trim().split("\\s+")), REMIND,
                words("pm am shaam sham raat dopahar subah morning evening night afternoon शाम रात दोपहर सुबह kal aaj tomorrow today कल आज baad बाद"));
        return c;
    }

    private static boolean has(List<String> t, String list) {
        return first(t, words(list)) >= 0;
    }
}
