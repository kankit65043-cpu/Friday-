package com.ankit.voice;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;
import java.util.*;

/**
 * Doosre apps ke andar button dabata hai. Sirf tab kaam karta hai jab aap koi command dete hain.
 * Apps apna layout badlein to yahan ke ID / text badalne padenge.
 */
public class FridayService extends AccessibilityService {
    static final String YOUTUBE = "com.google.android.youtube";
    static final String INSTAGRAM = "com.instagram.android";
    static FridayService instance;

    /** true lautane ka matlab step poora hua. */
    private interface Step { boolean run(AccessibilityNodeInfo root); }
    private interface Match { boolean ok(AccessibilityNodeInfo n); }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextToSpeech tts;

    @Override
    protected void onServiceConnected() {
        instance = this;
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { handler.removeCallbacksAndMessages(null); }

    @Override
    public boolean onUnbind(Intent intent) {
        handler.removeCallbacksAndMessages(null);
        if (tts != null) tts.shutdown();
        instance = null;
        return super.onUnbind(intent);
    }

    private void say(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        if (tts != null) tts.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "friday");
    }

    // ---------- Kaam ----------

    void playFirstVideo() {
        runSteps(YOUTUBE, "Video apne aap nahi chala, list se chun lijiye", root -> {
            AccessibilityNodeInfo video = find(root, n -> {
                String d = lower(n.getContentDescription());
                boolean isVideo = d.contains("play video") || (d.contains("views") && d.contains("minute"));
                return isVideo && !d.contains("sponsored");
            });
            return click(video);
        });
    }

    void sendWhatsApp(String app, String name, String text) {
        runSteps(app, "WhatsApp message nahi gaya, chat check kijiye", root -> {
            // Send tabhi dabao jab box mein wahi message likha ho
            AccessibilityNodeInfo box = find(root, n -> n.isEditable()
                    && n.getText() != null && n.getText().toString().trim().equals(text.trim()));
            if (box == null) return false;
            AccessibilityNodeInfo send = find(root, n -> (app + ":id/send").equals(n.getViewIdResourceName())
                    || lower(n.getContentDescription()).equals("send"));
            if (!click(send)) return false;
            say(name + " ko WhatsApp par Send daba diya");
            return true;
        });
    }

    void follow(String who) {
        String want = plain(who);
        if (want.isEmpty()) { say("Naam English mein boliye"); return; }
        runSteps(INSTAGRAM, "Follow nahi ho paya, Instagram mein khud check kijiye",
            // 1. Search tab
            root -> click(find(root, n -> (INSTAGRAM + ":id/search_tab").equals(n.getViewIdResourceName())
                    || lower(n.getContentDescription()).startsWith("search and explore"))),
            // 2. Search box mein naam likho
            root -> {
                AccessibilityNodeInfo box = find(root, n ->
                        (INSTAGRAM + ":id/action_bar_search_edit_text").equals(n.getViewIdResourceName()));
                if (box == null) return false;
                if (!box.isEditable()) { click(box); return false; }
                Bundle args = new Bundle();
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, who);
                if (box.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true;
                click(box);
                return false;
            },
            // 3. Sirf wahi account kholo jiska naam poora milta ho
            root -> click(find(root, n -> !n.isEditable() && plain(n.getText()).equals(want))),
            // 4. Profile page par Follow
            root -> {
                if (find(root, n -> n.isEditable()) != null) return false;
                AccessibilityNodeInfo button = find(root, n ->
                        (INSTAGRAM + ":id/profile_header_follow_button").equals(n.getViewIdResourceName()));
                if (button == null) {
                    if (find(root, n -> lower(n.getText()).contains("followers")
                            || lower(n.getContentDescription()).contains("followers")) == null) return false;
                    button = find(root, n -> {
                        String x = lower(n.getText());
                        return x.equals("follow") || x.equals("follow back")
                                || x.equals("following") || x.equals("requested");
                    });
                }
                if (button == null) return false;
                String label = lower(button.getText()) + " " + lower(button.getContentDescription());
                if (label.contains("following") || label.contains("requested")) {
                    say("Pehle se follow ya request kiya hua hai");
                    return true;
                }
                if (!click(button)) return false;
                say(who + " par Follow daba diya");
                return true;
            });
    }

    // ---------- Madad ----------

    /** Har step ko aadhe second mein dobara try karta hai, 15 second tak. */
    private void runSteps(String app, String failMessage, Step... steps) {
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(new Runnable() {
            int index = 0, tries = 0;
            @Override
            public void run() {
                AccessibilityNodeInfo root = getRootInActiveWindow();
                // Sahi app saamne ho tabhi kuch dabao
                boolean done = root != null && app.contentEquals(String.valueOf(root.getPackageName()))
                        && steps[index].run(root);
                if (done) { index++; tries = 0; } else tries++;
                if (index >= steps.length) return;
                if (tries > 30) { say(failMessage); return; }
                handler.postDelayed(this, done ? 1500 : 500);
            }
        }, 2500);
    }

    /** Screen par upar se neeche pehla dikhne wala node jo match kare. */
    private AccessibilityNodeInfo find(AccessibilityNodeInfo node, Match match) {
        if (node == null) return null;
        if (node.isVisibleToUser() && match.ok(node)) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo found = find(node.getChild(i), match);
            if (found != null) return found;
        }
        return null;
    }

    private boolean click(AccessibilityNodeInfo node) {
        while (node != null && !node.isClickable()) node = node.getParent();
        return node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private static String lower(CharSequence s) {
        return s == null ? "" : s.toString().toLowerCase(Locale.ROOT).trim();
    }

    /** "virat.kohli" aur "Virat Kohli" dono "viratkohli" ban jate hain. */
    private static String plain(CharSequence s) {
        return lower(s).replaceAll("[^\\p{L}\\p{M}\\p{N}]", "");
    }
}
